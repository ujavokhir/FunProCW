﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zurumbia.DAL
{
    //METHODS FOR GETTING ALL PAYMENTS
    public class PaymentList
    {
        public List<Payment> GetAllPayments()
        {
            return new PaymentManager().GetAll();
        }

    }
}
