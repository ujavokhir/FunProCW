﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Zurumbia.DAL
{
    public class Worker
    {
        public int Id { get; set; }

        private string name;
        private int region;
        private double hours;
        
        public string Name
        {
            get => name;
            set
            {
                if (string.IsNullOrEmpty(value))
                    throw new Exception("Name cannot be empty");
                name = value;
            }
        }

        public int Region
        {
            get => region;
            set
            {
                if (value < 1 || value > 10)
                    throw new Exception("Region should be between 1 and 10");
                region = value;
            }
        }

        public double Hours
        {
            get => hours;
            set
            {
                if (value < 0)
                    throw new Exception("Hours should be written correctly");
                hours = value;
            }
        }

        public Worker()
        {

        }

        public Worker(string name, int region, double hours)
        {
            Name = name;
            Region = region;
            Hours = hours;
        }

        
        public override string ToString()
        {
            return Name;
        }


    }
}
