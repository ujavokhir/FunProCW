﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zurumbia.DAL
{
    //SORTING AND SEARCHING METHODS FOR WORKERS
    public  class WorkerList
    {
        public List<Worker> GetAllWorkers()
        {
            return new WorkerManager().GetAll();
        }

        public List<Worker> Sort(ByAttribute attribute)
        {
            switch (attribute)  
            {
                case ByAttribute.Name:
                    return GetAllWorkers().OrderBy(a => a.Name).ToList();
                case ByAttribute.Id:
                    return GetAllWorkers().OrderBy(a => a.Id).ToList();
                case ByAttribute.Region:
                    return GetAllWorkers().OrderBy(a => a.Region).ToList();
                case ByAttribute.Hours:
                    return GetAllWorkers().OrderBy(a => a.Hours).ToList();
            }

            //if we are here - something went wrong
            return null;
        }

        public List<Worker> Search(string value, ByAttribute attribute)
        {
            switch (attribute)
            {
                case ByAttribute.Name:
                    return GetAllWorkers().Where(a => a.Name.ToUpper().Contains(value.ToUpper())).ToList();
                case ByAttribute.Id:
                    return GetAllWorkers().Where(a => Convert.ToInt32(a.Id) == Convert.ToInt32(value)).ToList();
                case ByAttribute.Region: 
                    return GetAllWorkers().Where(a => Convert.ToInt32(a.Region) == Convert.ToInt32(value)).ToList();
                    
            }
            //if we are here - something went wrong
            return null;
        }

    }
}
