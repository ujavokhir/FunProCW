﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlServerCe;

namespace Zurumbia.DAL
{
    public class PaymentManager : DbManager
    {
        //METHODS AND FUNCTIONS FOR PAYMENT CLASS -> CRUD
        public void Create(Payment c)
        {
            var connection = Connection;
            try
            {
                var sql = $@"
                    INSERT INTO rp_region_payment (
                        rp_date_12026,
                        rp_region_12026,
                        rp_headcount_12026,
                        rp_limit_12026,
                        rp_paid_12026
                    ) 
                    VALUES(
                        '{c.Date:yyyy/MMMM/dd}',
                        '{c.Region}',
                        '{c.Headcount}',
                        '{c.Limit}',
                        '{c.Paid}'
                    )";
                var command = new SqlCeCommand(sql, connection);
                connection.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (connection.State != ConnectionState.Closed)
                {
                    connection.Close();
                }

            }

        }

        public void Update(Payment c)
        {
            var connection = Connection;
            try
            {
                var sql = $@"
                    UPDATE rp_region_payment SET
                    rp_date_12026 = '{c.Date:yyyy/MMMM/dd}',
                    rp_region_12026 = '{c.Region}',
                    rp_headcount_12026 = '{c.Headcount}',
                    rp_limit_12026 = '{c.Limit}',
                    rp_paid_12026 = '{c.Paid}'
                    WHERE rp_id_12026 = {c.Id}";
                var command = new SqlCeCommand(sql, connection);
                connection.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (connection.State != ConnectionState.Closed)
                {
                    connection.Close();
                }
            }
        }

        public void Delete(int id)
        {
            var connection = Connection;
            try
            {
                var sql = $"DELETE FROM rp_region_payment WHERE rp_id_12026 = {id}";
                var command = new SqlCeCommand(sql, connection);
                connection.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (connection.State != ConnectionState.Closed)
                {
                    connection.Close();
                }
            }
        }

        public Payment GetById(int id)
        {
            var connection = Connection;
            try
            {
                var sql = $@"
                    SELECT 
                    rp_id_12026, 
                    rp_region_12026,
                    rp_headcount_12026,
                    rp_limit_12026,
                    rp_paid_12026
                    FROM rp_region_payment
                    WHERE rp_id_12026 = {id}";
                var command = new SqlCeCommand(sql, connection);
                connection.Open();
                var reader = command.ExecuteReader();
                if (reader.Read())
                {
                    var c = new Payment
                    {
                        Id = Convert.ToInt32(reader.GetValue(0)),
                        Date = Convert.ToDateTime(reader.GetValue(1)),
                        Region = Convert.ToInt32(reader.GetValue(2)),
                        Headcount = Convert.ToInt32(reader.GetValue(3)),
                        Limit = Convert.ToInt32(reader.GetValue(4)),
                        Paid = Convert.ToInt32(reader.GetValue(5))
                    };
                    return c;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (connection.State != ConnectionState.Closed)
                {
                    connection.Close();
                }

            }

            // if we are here - something went wrong
            return null;
        }

        public List<Payment> GetAll()
        {
            var connection = Connection;
            var result = new List<Payment>();
            try
            {
                var sql = $@"
                    SELECT 
                    rp_id_12026,
                    rp_date_12026,
                    rp_region_12026,
                    rp_headcount_12026,
                    rp_limit_12026,
                    rp_paid_12026
                    FROM rp_region_payment";
                var command = new SqlCeCommand(sql, connection);
                connection.Open();
                var reader = command.ExecuteReader();
                while (reader.Read())
                {
                    var c = new Payment
                    {
                        Id = Convert.ToInt32(reader.GetValue(0)),
                        Date = Convert.ToDateTime(reader.GetValue(1)),
                        Region = Convert.ToInt32(reader.GetValue(2)),
                        Headcount = Convert.ToInt32(reader.GetValue(3)),
                        Limit = Convert.ToInt32(reader.GetValue(4)),
                        Paid = Convert.ToInt32(reader.GetValue(5))
                    };
                    result.Add(c);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (connection.State != ConnectionState.Closed)
                {
                    connection.Close();
                }

            }

            return result;
        }

    }
}
