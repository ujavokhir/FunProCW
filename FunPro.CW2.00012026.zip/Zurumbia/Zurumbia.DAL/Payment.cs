﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zurumbia.DAL
{
    public class Payment
    {
        
        public int Id { get; set; }

        public DateTime Date { get; set; }

        private int region;
        public int Region {
            get => region; 
            set
            {
                if (value < 0 || value > 10)
                {
                    throw new Exception("Region must be choosen between 1 and 10");
                }
                region = value;
            }
        }

        public int Headcount { get; set; }

        public int Limit { get; set; }

        public decimal Paid { get; set; }

        

        public Payment(DateTime date, int region, int headcount, int limit, decimal paid)
        {
            Date = date;        
            Region = region;
            Headcount = headcount;
            Limit = limit;
            Paid = paid;
        }

        public Payment()
        {

        }

    }
}
