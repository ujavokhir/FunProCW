﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlServerCe;

namespace Zurumbia.DAL
{
    public class WorkerManager : DbManager
    {
        //METHODS AND FUNCTIONS FOR WORKER CLASS -> CRUD
        public void Create(Worker a)
        {
            var connection = Connection;
            try
            {
                var sql = $@"
                    INSERT INTO sw_social_worker 
                    (sw_name_12026, sw_region_12026, sw_hours_12026) 
                    VALUES('{a.Name}', '{a.Region}', '{a.Hours}')";
                var command = new SqlCeCommand(sql, connection);
                connection.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (connection.State != ConnectionState.Closed)
                {
                    connection.Close();
                }

            }
        }

        public void Update(Worker a)
        {
            var connection = Connection;
            try
            {
                var sql = $@"
                    UPDATE sw_social_worker SET 
                        sw_name_12026 = '{a.Name}', 
                        sw_region_12026 = '{a.Region}', 
                        sw_hours_12026 = '{a.Hours}'
                    WHERE sw_id_12026 = {a.Id}";
                var command = new SqlCeCommand(sql, connection);
                connection.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (connection.State != ConnectionState.Closed)
                {
                    connection.Close();
                }

            }
        }

        public void Delete(int id)
        {
            var connection = Connection;
            try
            {
                var sql = $@"DELETE FROM sw_social_worker 
                          WHERE sw_id_12026 = {id}";
                var command = new SqlCeCommand(sql, connection);
                connection.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (connection.State != ConnectionState.Closed)
                {
                    connection.Close();
                }
            }
        }

        public Worker GetById(int id)
        {
            var connection = Connection;
            try
            {
                var sql = $@"
                          SELECT 
                              sw_id_12026, 
                              sw_name_12026, 
                              sw_region_12026, 
                              sw_hours_12026
                          FROM sw_social_worker
                          WHERE sw_id_12026 = {id}";
                var command = new SqlCeCommand(sql, connection);
                connection.Open();
                var reader = command.ExecuteReader();
                if (reader.Read())
                {
                    var a = GetFromReader(reader);
                    return a;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (connection.State != ConnectionState.Closed)
                {
                    connection.Close();
                }
            }

            // if we are here - something went wrong
            return null;
        }

        public List<Worker> GetAll()
        {
            var connection = Connection;
            var result = new List<Worker>();
            try
            {
                var sql = "SELECT sw_id_12026, sw_name_12026, sw_region_12026, sw_hours_12026 FROM sw_social_worker";
                var command = new SqlCeCommand(sql, connection);
                connection.Open();
                var reader = command.ExecuteReader();
                while (reader.Read())
                {
                    var a = GetFromReader(reader);
                    result.Add(a);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (connection.State != ConnectionState.Closed)
                {
                    connection.Close();
                }
            }

            return result;
        }

        private Worker GetFromReader(SqlCeDataReader reader)
        {
            var a = new Worker
            {
                Id = Convert.ToInt32(reader.GetValue(0)),
                Name = reader.GetValue(1).ToString(),
                Region = Convert.ToInt32(reader.GetValue(2)),
                Hours = Convert.ToDouble(reader.GetValue(3)),
            };

            return a;
        }
    }
}
