﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Zurumbia.DAL;

namespace Zurumbia
{
    public partial class RegionPaymentListForm : Form
    {
        
        public RegionPaymentListForm()
        {
            InitializeComponent();
        }

        public Payment Payment { get; set; }

        public void LoadData()
        {
            dgvPayment.DataMember = "";
            dgvPayment.DataSource = null;
            dgvPayment.DataSource = new WorkerList().Search(numRegion.Value.ToString(), ByAttribute.Region);
        }
        private void RegionPaymentListForm_Load(object sender, EventArgs e)
        {
            MdiParent = MyForms.GetForm<ParentForm>();
            Payment = new Payment();

            dtpDate.Format = DateTimePickerFormat.Custom;
            dtpDate.CustomFormat = "yyyy/MMMM/01";
        }

        public decimal AllHoursWorked()
        {
            decimal AllHoursWorked = 0;

            for (int i = 0; i < dgvPayment.Rows.Count; i++)
            {
                AllHoursWorked += Convert.ToInt32(dgvPayment.Rows[i].Cells[3].Value);
            }
            return AllHoursWorked;
        }

       

        public decimal TotalPaidHours()
        {
            if (numLimit.Value < AllHoursWorked())
            {
                decimal extraHours = AllHoursWorked() - numLimit.Value;               
                return numLimit.Value;
            }
                return AllHoursWorked();
            
        }

        public decimal CalculatingAllHoursWorked()
        {
            decimal AllHoursWorked = 0;
            for (int i = 0; i < dgvPayment.Rows.Count; i++)
            {
                AllHoursWorked = +Convert.ToDecimal(dgvPayment.Rows[i].Cells[3].Value);
            }
            return AllHoursWorked;
        }

        public void AddingPayment()
        {
            Payment.Date = Convert.ToDateTime(dtpDate.Value.AddDays(1));
            Payment.Region = Convert.ToInt32(numRegion.Value);
            Payment.Headcount = Convert.ToInt32(dgvPayment.Rows.Count);
            Payment.Limit = Convert.ToInt32(numLimit.Value);
            Payment.Paid = TotalPaidHours();
        }

        public void UpdatingSocialWorkerData()
        {
            for (int i = 0; i < dgvPayment.Rows.Count; i++)
            {

                dgvPayment.Rows[i].Cells[3].Value = dgvPayment.Rows[i].Cells[5].Value;
                dgvPayment.Rows[i].Cells[4].Value = 0;
                dgvPayment.Rows[i].Cells[5].Value = 0;

                var c = (Worker)dgvPayment.Rows[i].DataBoundItem;
                new WorkerEditForm().UpdateWorkerAutomically(c);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnSavePayment_Click(object sender, EventArgs e)
        {
            AddingPayment();
            var manager = new PaymentManager();
            manager.Create(Payment);

            UpdatingSocialWorkerData();
            MessageBox.Show($"Some extra hours transferred to the following month");
            Close();
        }

        private void dgvPayment_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void btnLoadData_Click(object sender, EventArgs e)
        {
            if (dtpDate.Value == null)
                MessageBox.Show("Select the month, please");
            else if (numRegion.Value > 10 || numRegion.Value < 1)
                MessageBox.Show("Region number can be only between 1 and 10");
            else if (numLimit.Value <= 0)
                MessageBox.Show("Please set a limit for payings");
            else
            {
                LoadData();

                decimal PaidPercent = 0;

                for (int i = 0; i < dgvPayment.Rows.Count; i++)
                {
                    PaidPercent = decimal.Round(numLimit.Value / AllHoursWorked(), 2);
                    if (PaidPercent >= 1)
                    {
                        dgvPayment.Rows[i].Cells[4].Value = Convert.ToInt32(dgvPayment.Rows[i].Cells[3].Value.ToString());
                        dgvPayment.Rows[i].Cells[3].Value = 0;
                    }
                    else
                    {
                        dgvPayment.Rows[i].Cells[4].Value = PaidPercent * Convert.ToInt32(dgvPayment.Rows[i].Cells[3].Value.ToString());

                    }

                    if (decimal.Parse(dgvPayment.Rows[i].Cells[4].Value.ToString()) > decimal.Parse(dgvPayment.Rows[i].Cells[3].Value.ToString()))
                    {
                        dgvPayment.Rows[i].Cells[5].Value = 0;
                    }
                    else
                    {
                        dgvPayment.Rows[i].Cells[5].Value = decimal.Parse(dgvPayment.Rows[i].Cells[3].Value.ToString()) - decimal.Parse(dgvPayment.Rows[i].Cells[4].Value.ToString());
                    }
                }

                lblTotalPaidHours.Text = $"Total paid hours: {TotalPaidHours()}";
            }
        }
    }
}
