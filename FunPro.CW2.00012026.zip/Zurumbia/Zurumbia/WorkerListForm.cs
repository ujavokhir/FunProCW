﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Zurumbia.DAL;

namespace Zurumbia
{
    public partial class WorkerListForm : Form
    {
        public WorkerListForm()
        {
            InitializeComponent();
        }


        private void WorkerListForm_Load(object sender, EventArgs e)
        {
            MdiParent = MyForms.GetForm<ParentForm>();
            LoadData();
        }

        

        public void LoadData()
        {
            dgv.DataMember = "";
            dgv.DataSource = null;
            dgv.DataSource = new WorkerList().GetAllWorkers();
        }

        private void btnSearch_Click_1(object sender, EventArgs e)
        {
            if (cbxSearch.SelectedIndex < 0)
                MessageBox.Show("Select an attribute to search by");
            else if (string.IsNullOrWhiteSpace(tbxSearch.Text))
                MessageBox.Show("Provide the search term");
            else
            { 
                ByAttribute selectedAttribute;
                if (cbxSearch.SelectedIndex == 0)
                    selectedAttribute = ByAttribute.Name;
                else if (cbxSearch.SelectedIndex == 1)
                    selectedAttribute = ByAttribute.Id;
                else selectedAttribute = ByAttribute.Region;


                dgv.DataMember = "";
                dgv.DataSource = null;
                dgv.DataSource = new WorkerList().Search(tbxSearch.Text, selectedAttribute);
            }
        }

        private void btnSort_Click(object sender, EventArgs e)
        {
            if (cbxSort.SelectedIndex < 0)
                MessageBox.Show("Select an attribute to sort by");
            else
            {
                ByAttribute selectedAttribute;
                if (cbxSort.SelectedIndex == 0)
                    selectedAttribute = ByAttribute.Name;
                else if (cbxSort.SelectedIndex == 1)
                    selectedAttribute = ByAttribute.Id;
                else if (cbxSort.SelectedIndex == 2)
                    selectedAttribute = ByAttribute.Region;
                else 
                    selectedAttribute = ByAttribute.Hours;



                dgv.DataMember = "";
                dgv.DataSource = null;
                dgv.DataSource = new WorkerList().Sort(selectedAttribute);
            }
        }



        private void btnAdd_Click(object sender, EventArgs e)
        {
                new WorkerEditForm().CreateNewWorker();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (dgv.SelectedRows.Count == 0)
                MessageBox.Show("Please select a worker");
            else
            {
                var c = (Worker)dgv.SelectedRows[0].DataBoundItem;
                new WorkerEditForm().UpdateWorker(c);

            }


        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
                if (dgv.SelectedRows.Count == 0)
                    MessageBox.Show("Please select a worker to delete");
                else
                {
                    var c = (Worker)dgv.SelectedRows[0].DataBoundItem;
                    new WorkerManager().Delete(c.Id);
                    LoadData();
                }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void txbSearch_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
