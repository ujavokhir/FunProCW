﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Zurumbia.DAL;

namespace Zurumbia
{
    public partial class ParentForm : Form
    {
        public ParentForm()
        {
            InitializeComponent();
        }

        private void foToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var form = new AboutForm();
            form.ShowDialog();
        }

        

        private void allWorkersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MyForms.GetForm<WorkerListForm>().Show();
        }

        private void allPaymentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MyForms.GetForm<PaymentListForm>().Show();
        }

        private void ParentForm_Load(object sender, EventArgs e)
        {

        }

        private void newWorkerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new WorkerEditForm().CreateNewWorker();
        }

        private void newPaymentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MyForms.GetForm<RegionPaymentListForm>().Show();
        }
    }
}
