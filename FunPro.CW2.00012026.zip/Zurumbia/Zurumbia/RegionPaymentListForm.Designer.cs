﻿namespace Zurumbia
{
    partial class RegionPaymentListForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblRegion = new System.Windows.Forms.Label();
            this.btnLoadData = new System.Windows.Forms.Button();
            this.numRegion = new System.Windows.Forms.NumericUpDown();
            this.dtpDate = new System.Windows.Forms.DateTimePicker();
            this.numLimit = new System.Windows.Forms.NumericUpDown();
            this.lblMonth = new System.Windows.Forms.Label();
            this.lblLimit = new System.Windows.Forms.Label();
            this.dgvPayment = new System.Windows.Forms.DataGridView();
            this.PaidMoney = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UnpaidMoney = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnSavePayment = new System.Windows.Forms.Button();
            this.btnCancelPayment = new System.Windows.Forms.Button();
            this.lblTotalPaidHours = new System.Windows.Forms.Label();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.regionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.hoursDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.workerBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.numRegion)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numLimit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPayment)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.workerBindingSource2)).BeginInit();
            this.SuspendLayout();
            // 
            // lblRegion
            // 
            this.lblRegion.AutoSize = true;
            this.lblRegion.Location = new System.Drawing.Point(12, 22);
            this.lblRegion.Name = "lblRegion";
            this.lblRegion.Size = new System.Drawing.Size(41, 13);
            this.lblRegion.TabIndex = 0;
            this.lblRegion.Text = "Region";
            // 
            // btnLoadData
            // 
            this.btnLoadData.Location = new System.Drawing.Point(15, 93);
            this.btnLoadData.Name = "btnLoadData";
            this.btnLoadData.Size = new System.Drawing.Size(194, 23);
            this.btnLoadData.TabIndex = 1;
            this.btnLoadData.Text = "Load Data";
            this.btnLoadData.UseVisualStyleBackColor = true;
            this.btnLoadData.Click += new System.EventHandler(this.btnLoadData_Click);
            // 
            // numRegion
            // 
            this.numRegion.Location = new System.Drawing.Point(89, 15);
            this.numRegion.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numRegion.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numRegion.Name = "numRegion";
            this.numRegion.Size = new System.Drawing.Size(120, 20);
            this.numRegion.TabIndex = 2;
            this.numRegion.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // dtpDate
            // 
            this.dtpDate.Location = new System.Drawing.Point(89, 41);
            this.dtpDate.Name = "dtpDate";
            this.dtpDate.Size = new System.Drawing.Size(120, 20);
            this.dtpDate.TabIndex = 3;
            // 
            // numLimit
            // 
            this.numLimit.Location = new System.Drawing.Point(89, 67);
            this.numLimit.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.numLimit.Name = "numLimit";
            this.numLimit.Size = new System.Drawing.Size(120, 20);
            this.numLimit.TabIndex = 4;
            // 
            // lblMonth
            // 
            this.lblMonth.AutoSize = true;
            this.lblMonth.Location = new System.Drawing.Point(12, 48);
            this.lblMonth.Name = "lblMonth";
            this.lblMonth.Size = new System.Drawing.Size(37, 13);
            this.lblMonth.TabIndex = 5;
            this.lblMonth.Text = "Month";
            // 
            // lblLimit
            // 
            this.lblLimit.AutoSize = true;
            this.lblLimit.Location = new System.Drawing.Point(12, 74);
            this.lblLimit.Name = "lblLimit";
            this.lblLimit.Size = new System.Drawing.Size(28, 13);
            this.lblLimit.TabIndex = 6;
            this.lblLimit.Text = "Limit";
            // 
            // dgvPayment
            // 
            this.dgvPayment.AllowUserToAddRows = false;
            this.dgvPayment.AllowUserToDeleteRows = false;
            this.dgvPayment.AutoGenerateColumns = false;
            this.dgvPayment.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPayment.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.nameDataGridViewTextBoxColumn,
            this.regionDataGridViewTextBoxColumn,
            this.hoursDataGridViewTextBoxColumn,
            this.PaidMoney,
            this.UnpaidMoney});
            this.dgvPayment.DataSource = this.workerBindingSource2;
            this.dgvPayment.Location = new System.Drawing.Point(12, 132);
            this.dgvPayment.Name = "dgvPayment";
            this.dgvPayment.ReadOnly = true;
            this.dgvPayment.Size = new System.Drawing.Size(644, 212);
            this.dgvPayment.TabIndex = 7;
            this.dgvPayment.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPayment_CellContentClick);
            // 
            // PaidMoney
            // 
            this.PaidMoney.HeaderText = "Paid Money";
            this.PaidMoney.Name = "PaidMoney";
            this.PaidMoney.ReadOnly = true;
            // 
            // UnpaidMoney
            // 
            this.UnpaidMoney.HeaderText = "Unpaid Money";
            this.UnpaidMoney.Name = "UnpaidMoney";
            this.UnpaidMoney.ReadOnly = true;
            // 
            // btnSavePayment
            // 
            this.btnSavePayment.Location = new System.Drawing.Point(528, 375);
            this.btnSavePayment.Name = "btnSavePayment";
            this.btnSavePayment.Size = new System.Drawing.Size(91, 32);
            this.btnSavePayment.TabIndex = 8;
            this.btnSavePayment.Text = "Save";
            this.btnSavePayment.UseVisualStyleBackColor = true;
            this.btnSavePayment.Click += new System.EventHandler(this.btnSavePayment_Click);
            // 
            // btnCancelPayment
            // 
            this.btnCancelPayment.Location = new System.Drawing.Point(646, 375);
            this.btnCancelPayment.Name = "btnCancelPayment";
            this.btnCancelPayment.Size = new System.Drawing.Size(89, 32);
            this.btnCancelPayment.TabIndex = 9;
            this.btnCancelPayment.Text = "Cancel";
            this.btnCancelPayment.UseVisualStyleBackColor = true;
            this.btnCancelPayment.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // lblTotalPaidHours
            // 
            this.lblTotalPaidHours.AutoSize = true;
            this.lblTotalPaidHours.Font = new System.Drawing.Font("Mongolian Baiti", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalPaidHours.Location = new System.Drawing.Point(11, 394);
            this.lblTotalPaidHours.Name = "lblTotalPaidHours";
            this.lblTotalPaidHours.Size = new System.Drawing.Size(179, 23);
            this.lblTotalPaidHours.TabIndex = 10;
            this.lblTotalPaidHours.Text = "Total paid hours: ";
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            this.nameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // regionDataGridViewTextBoxColumn
            // 
            this.regionDataGridViewTextBoxColumn.DataPropertyName = "Region";
            this.regionDataGridViewTextBoxColumn.HeaderText = "Region";
            this.regionDataGridViewTextBoxColumn.Name = "regionDataGridViewTextBoxColumn";
            this.regionDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // hoursDataGridViewTextBoxColumn
            // 
            this.hoursDataGridViewTextBoxColumn.DataPropertyName = "Hours";
            this.hoursDataGridViewTextBoxColumn.HeaderText = "Hours";
            this.hoursDataGridViewTextBoxColumn.Name = "hoursDataGridViewTextBoxColumn";
            this.hoursDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // workerBindingSource2
            // 
            this.workerBindingSource2.DataSource = typeof(Zurumbia.DAL.Worker);
            // 
            // RegionPaymentListForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblTotalPaidHours);
            this.Controls.Add(this.btnCancelPayment);
            this.Controls.Add(this.btnSavePayment);
            this.Controls.Add(this.dgvPayment);
            this.Controls.Add(this.lblLimit);
            this.Controls.Add(this.lblMonth);
            this.Controls.Add(this.numLimit);
            this.Controls.Add(this.dtpDate);
            this.Controls.Add(this.numRegion);
            this.Controls.Add(this.btnLoadData);
            this.Controls.Add(this.lblRegion);
            this.Name = "RegionPaymentListForm";
            this.Text = "RegionPayment";
            this.Load += new System.EventHandler(this.RegionPaymentListForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numRegion)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numLimit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPayment)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.workerBindingSource2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblRegion;
        private System.Windows.Forms.Button btnLoadData;
        private System.Windows.Forms.NumericUpDown numRegion;
        private System.Windows.Forms.DateTimePicker dtpDate;
        private System.Windows.Forms.NumericUpDown numLimit;
        private System.Windows.Forms.Label lblMonth;
        private System.Windows.Forms.Label lblLimit;
        private System.Windows.Forms.DataGridView dgvPayment;
        private System.Windows.Forms.Button btnSavePayment;
        private System.Windows.Forms.Button btnCancelPayment;
        private System.Windows.Forms.Label lblTotalPaidHours;
        private System.Windows.Forms.BindingSource workerBindingSource2;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn regionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn hoursDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn PaidMoney;
        private System.Windows.Forms.DataGridViewTextBoxColumn UnpaidMoney;
    }
}