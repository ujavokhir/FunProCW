﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Zurumbia.DAL;

namespace Zurumbia
{
    public partial class WorkerEditForm : Form
    {

        public Boolean isAutomically = false;

        public WorkerEditForm()
        {
            InitializeComponent();
        }


        public Worker Worker 
        {
            get; set;
        }
        public FormMode Mode { get; set; }

        public void CreateNewWorker()
        {
            isAutomically = false;
            Mode = FormMode.CreateNew;
            Worker = new Worker();
            MdiParent = MyForms.GetForm<ParentForm>();
            Show();
        }
        
        public void UpdateWorker(Worker worker)
        {
            Mode = FormMode.Update;
            Worker = worker;
            ShowWorkerInControls();
            MdiParent = MyForms.GetForm<ParentForm>();
            Show();
        }

        public void UpdateWorkerAutomically(Worker worker)
        {
            isAutomically = true;
            Mode = FormMode.Update;
            Worker = worker;
            ShowWorkerInControls();
            Save();
        }

        private void ShowWorkerInControls()
        {
            numRegion.Value = Worker.Region;
            tbxName.Text = Worker.Name;
            tbxHours.Text = Worker.Hours.ToString();

        }

        private void GrabUserInput()
        {
            Worker.Name = tbxName.Text;
            Worker.Hours = Convert.ToDouble(tbxHours.Text);
            Worker.Region = Convert.ToInt32(numRegion.Value);
        }


        private void WorkerEditForm_Load(object sender, EventArgs e)
        {
            if (isAutomically == true)
            {
                Save();
            }
            else
            {
                MdiParent = MyForms.GetForm<ParentForm>();
            }
        }

        public void Save()
        {
            try
            {
                GrabUserInput();
                var manager = new WorkerManager();
                if (Mode == FormMode.CreateNew)
                {
                    manager.Create(Worker);
                }
                else
                {
                    manager.Update(Worker);
                }
                MyForms.GetForm<WorkerListForm>().LoadData();
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            Save();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void numRegion_ValueChanged(object sender, EventArgs e)
        {

        }

        private void lblName_Click(object sender, EventArgs e)
        {

        }
    }
}
