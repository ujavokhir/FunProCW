﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Zurumbia.DAL;

namespace Zurumbia
{
    public partial class PaymentListForm : Form
    {
        public PaymentListForm()
        {
            InitializeComponent();
        }

        private void PaymentListForm_Load(object sender, EventArgs e)
        {
            MdiParent = MyForms.GetForm<ParentForm>();
            LoadData();
        }

        public void LoadData()
        {
            dgvPaymentList.DataMember = "";
            dgvPaymentList.DataSource = null;
            dgvPaymentList.DataSource = new PaymentList().GetAllPayments();
        }

        private void dgvPaymentList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
